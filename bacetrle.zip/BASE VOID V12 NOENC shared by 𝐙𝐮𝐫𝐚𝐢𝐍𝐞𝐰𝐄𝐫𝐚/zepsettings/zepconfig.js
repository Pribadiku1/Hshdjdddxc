module.exports = {
  tokenBot: "7872129457:AAEV-5P2Al9Ya7XYbJzlFqBFSFt5WjQeeaA",
  ownerID: "1575390626",
};

//                ©The Zephyrine